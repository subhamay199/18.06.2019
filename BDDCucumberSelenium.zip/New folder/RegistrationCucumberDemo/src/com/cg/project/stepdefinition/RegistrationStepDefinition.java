package com.cg.project.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.pagebeans.RegistrationPageBean;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {
private WebDriver driver;
private  RegistrationPageBean pageBean;

@Given("^User is accessing Registration Page on Browser$")
public void user_is_accessing_Registration_Page_on_Browser() throws Throwable {
	driver.get("D:\\WebPages\\RegistrationForm.html");
	pageBean=PageFactory.initElements(driver, RegistrationPageBean.class);
    //throw new PendingException();
}

@When("^User is trying to submit data withoud entering 'User Id'$")
public void user_is_trying_to_submit_data_withoud_entering_User_Id() throws Throwable {
   pageBean.clickSignUp();
   // throw new PendingException();
}

@Then("^'User Id should not be empty / length be between (\\d+) to (\\d+)' alert message should display$")
public void user_Id_should_not_be_empty_length_be_between_to_alert_message_should_display(int arg1, int arg2) throws Throwable {
    String expectedAlertMEssage="USer ID should not be empty/length be between 5 to 12";
    String actualAlertMEssage=driver.switchTo().alert().getText();
    Assert.assertEquals(expectedAlertMEssage, actualAlertMEssage);
  //  throw new PendingException();
}

@When("^User is trying to submit request without entering 'Password'$")
public void user_is_trying_to_submit_request_without_entering_Password() throws Throwable {
   driver.switchTo().alert().dismiss();
   pageBean.setUserId("subhamaysamanta");
   pageBean.clickSignUp();
   // throw new PendingException();
}

@Then("^'Password should not be empty / length be between (\\d+) to (\\d+)' alert message should display$")
public void password_should_not_be_empty_length_be_between_to_alert_message_should_display(int arg1, int arg2) throws Throwable {
	 String expectedAlertMEssage="Username should not be empty and must have alphabete characters only";
	    String actualAlertMEssage=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectedAlertMEssage, actualAlertMEssage);
  //  throw new PendingException();
}

@When("^User is trying to submit request without entering 'username'$")
public void user_is_trying_to_submit_request_without_entering_username() throws Throwable {
		driver.switchTo().alert().dismiss();
	   pageBean.setUserId("subhamay11");
	   pageBean.clickSignUp();
   // throw new PendingException();
}

@Then("^'Name should not be empty and must have alphabet characters only' alert message should display$")
public void name_should_not_be_empty_and_must_have_alphabet_characters_only_alert_message_should_display() throws Throwable {
   
    //throw new PendingException();
}

@When("^User is trying to submit request without entering 'address'$")
public void user_is_trying_to_submit_request_without_entering_address() throws Throwable {
		driver.switchTo().alert().dismiss();
	   pageBean.setPassword("sasasasa");
	   pageBean.setAddress("PUne@");
	   pageBean.clickSignUp();
   // throw new PendingException();
}

@Then("^'User address must have alphanumeric characters only' alert message should display$")
public void user_address_must_have_alphanumeric_characters_only_alert_message_should_display() throws Throwable {
	 String expectedAlertMEssage="User address must have alphanumeric characters only";
	    String actualAlertMEssage=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectedAlertMEssage, actualAlertMEssage);
    //throw new PendingException();
}

@When("^User is trying to submit request without selecting valid 'country'$")
public void user_is_trying_to_submit_request_without_selecting_valid_country() throws Throwable {
	driver.switchTo().alert().dismiss();
	pageBean.setCountry("India");
	pageBean.clickSignUp();
   // throw new PendingException();
}

@Then("^'Select your country from the list' alert message should display$")
public void select_your_country_from_the_list_alert_message_should_display() throws Throwable {
   
	 String expectedAlertMEssage="Select your country from the list";
	    String actualAlertMEssage=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectedAlertMEssage, actualAlertMEssage);
    //throw new PendingException();
}

@When("^User is trying to submit request without selecting valid 'zipCode'$")
public void user_is_trying_to_submit_request_without_selecting_valid_zipCode() throws Throwable {
	driver.switchTo().alert().dismiss();
	pageBean.setZip("42300111");
	pageBean.clickSignUp();
   // throw new PendingException();
}

@Then("^'Zip code must have numeric characters only' alert message should display$")
public void zip_code_must_have_numeric_characters_only_alert_message_should_display() throws Throwable {
	 String expectedAlertMEssage="Zip code must have numeric characters only";
	    String actualAlertMEssage=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectedAlertMEssage, actualAlertMEssage);
   // throw new PendingException();
}

@When("^User is trying to submit request without selecting valid 'email'$")
public void user_is_trying_to_submit_request_without_selecting_valid_email() throws Throwable {
	driver.switchTo().alert().dismiss();
	pageBean.setZip("423011");
	pageBean.setEmail("subhamaysamanta1997@gmail.com");
	pageBean.clickSignUp();
     // throw new PendingException();
}

@Then("^'You have entered an invalid email address' alert message should display$")
public void you_have_entered_an_invalid_email_address_alert_message_should_display() throws Throwable {
	 String expectedAlertMEssage="You have entered an invalid email address!";
	    String actualAlertMEssage=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectedAlertMEssage, actualAlertMEssage);
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^User is trying to submit request without selecting valid 'gender'$")
public void user_is_trying_to_submit_request_without_selecting_valid_gender() throws Throwable {
	driver.switchTo().alert().dismiss();
	pageBean.setEmail("subhamaysamanta1997@gmail.com");
	pageBean.clickSignUp();
//	 String expectedAlertMEssage="User is trying to submit request without selecting valid 'gender'$";
//	    String actualAlertMEssage=driver.switchTo().alert().getText();
//	    Assert.assertEquals(expectedAlertMEssage, actualAlertMEssage);
    //throw new PendingException();
}

@Then("^'Please select gender' alert message should display$")
public void please_select_gender_alert_message_should_display() throws Throwable {
	 String expectedAlertMEssage="Please select gender";
	    String actualAlertMEssage=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectedAlertMEssage, actualAlertMEssage);
   // throw new PendingException();
}

@When("^User is trying to submit request after entering valid set of information$")
public void user_is_trying_to_submit_request_after_entering_valid_set_of_information() throws Throwable {
	pageBean.setUserId("subhamay11");
	pageBean.setUsername("subhamaysamanta");
	pageBean.setPassword("sasasasa");
	pageBean.setAddress("Pune421002");
	pageBean.setCountry("India");
	pageBean.setZip("4213011");
	pageBean.setEmail("subhamaysamanta1997@gmail.com");
	pageBean.setGender("Male");
	pageBean.clickSignUp();
    //throw new PendingException();
}

@Then("^'Your registration with JobsWorld\\.com has successfully done plz check your registered email address to activate your account'$")
public void your_registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registered_email_address_to_activate_your_account() throws Throwable {
	 String expectedAlertMEssage="Your registration with JobsWorld.com has successfully done plz check your registered email address to activate your account";
	    String actualAlertMEssage=driver.switchTo().alert().getText();
	    Assert.assertEquals(expectedAlertMEssage, actualAlertMEssage);
    //throw new PendingException();
}
}