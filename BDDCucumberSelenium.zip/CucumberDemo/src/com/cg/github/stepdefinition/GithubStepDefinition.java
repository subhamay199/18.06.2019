package com.cg.github.stepdefinition;

import org.junit.Assert;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.pagebeans.LoginPage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GithubStepDefinition {
	private WebDriver driver;
	private LoginPage loginPage;
	@Before
	public void setUpTestEnv() {
		System.setProperty("webdriver.chrome.driver","D:\\3000142_Saptarshi_Das\\chromedriver.exe");	
	}
	@Given("^the user has entered in github\\.com$")
	public void the_user_has_entered_in_github_com() throws Throwable {
		driver=new ChromeDriver();
	    driver.get("https://github.com/login");
	    loginPage=PageFactory.initElements(driver, LoginPage.class);
	    throw new PendingException();
	}

	@When("^the user tries to login using username$")
	public void the_user_tries_to_login_using_username() throws Throwable {
		loginPage.setUsername("saptarsh@gmail.com");
	    loginPage.setPassword("fdgfdzgfdgd");
	    loginPage.toString();
	    throw new PendingException();
	}

	@Then("^it shows invalid username on login page$")
	public void it_shows_invalid_username_on_login_page() throws Throwable {
		String actialTitle=driver.getTitle();
	    String expectedTitle="sssdas";
	    Assert.assertEquals(expectedTitle, actialTitle);
	    throw new PendingException();
	}

	@When("^the user tries to login using username and invalid password$")
	public void the_user_tries_to_login_using_username_and_invalid_password() throws Throwable {
		loginPage.setUsername("kutan1612");
	    loginPage.setPassword("nilotpal1");
	    loginPage.clickSignIn();
	    throw new PendingException();
	}

	@Then("^it shows invalid password on login page$")
	public void it_shows_invalid_password_on_login_page() throws Throwable {
		String expectedErrorMessage="Incorrect username or password";
	    Assert.assertEquals(expectedErrorMessage, loginPage.getActualErrorMessage());
	    throw new PendingException();
	}

	@When("^the user tries to login using username and password$")
	public void the_user_tries_to_login_using_username_and_password() throws Throwable {
		loginPage.setUsername("kutan16");
	    loginPage.setPassword("kutan1");
	    loginPage.clickSignIn();
	    throw new PendingException();
	}

	@Then("^the use is able to login into his github Account$")
	public void the_use_is_able_to_login_into_his_github_Account() throws Throwable {
		String expectedErrorMessage="Incorrect username or password";
	    Assert.assertEquals(expectedErrorMessage, loginPage.getActualErrorMessage());
	    throw new PendingException();
	}
}
