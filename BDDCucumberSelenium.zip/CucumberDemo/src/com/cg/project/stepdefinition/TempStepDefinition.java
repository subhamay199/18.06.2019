package com.cg.project.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class TempStepDefinition {
	@Given("^User is on the transaction page, and the Debit/Credit card credentials that user entered previously, are correct\\.$")
	public void user_is_on_the_transaction_page_and_the_Debit_Credit_card_credentials_that_user_entered_previously_are_correct() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User clicks on \"(.*?)\" button in the previous page$")
	public void user_clicks_on_button_in_the_previous_page(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Refresh link appears$")
	public void refresh_link_appears() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
